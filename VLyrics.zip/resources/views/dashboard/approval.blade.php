@extends('dashboard.layouts.main')

@section('container')
<h1 class="text-center">Halaman Dalam Perbaikan</h1>
@endsection