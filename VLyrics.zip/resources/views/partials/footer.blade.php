<hr>
<footer class="footer mt-auto py-3 bg-light">
    <div class="container">
        <ul class="nav justify-content-center border-bottom pb-3 mb-3 ">
            <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Facebook</a></li>
            <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Instagram</a></li>
            <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">YouTube</a></li>
            <li class="nav-item"><a href="/tentang" class="nav-link px-2 text-muted">Pertanyaan</a></li>
        </ul>
        <p class="text-center text-muted">&copy; 2023 VLyrics, </p>
    </div>
</footer>
